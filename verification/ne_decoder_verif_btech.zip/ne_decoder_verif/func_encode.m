function retval = func_encode (input1, input2)

endfunction
