function h = func_get_h_matrix ()

endfunction
